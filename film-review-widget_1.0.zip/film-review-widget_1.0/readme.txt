=== Movie-search-box Film-review Widget ===
Contributors: Film-review.it link: http://www.filmreview.it/gadget 
the widget can be added to the sidebar.
* Instead of using the widget, you could use the function of Movie search box
embedding the html specified at http://www.filmreview.it/gadget  from anywhere in the template. 
=

Leave your questions, suggestions, bug reports, etc., at cscornajenghi@edmaster.it **2009-07-01: Version 1.0**
	*
Added option to provide custom bg color for the box ****Donate link:http://www.filmreview.it/gadget **
Tags: cerca film Requires at least:2.0 Tested up to:2.8 Stable tag:1.0
== Description ==
widget di film-review per offrire ai lettori del tuo sito informazioni, servizi e risorse gratuite sul cinema italiano e internazionale.
== Screenshots ==
/tags/screenshot.jpg
